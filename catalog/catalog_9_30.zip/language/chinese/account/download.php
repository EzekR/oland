<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading 
$_['heading_title']   = '下载文件';

// Text
$_['text_account']    = '我的账户';
$_['text_downloads']  = '下载文件';
$_['text_order']      = '订单号：';
$_['text_date_added'] = '添加日期：';
$_['text_name']       = '名字：';
$_['text_remaining']  = '备注：';
$_['text_size']       = '规格：';
$_['text_download']   = '下载';
$_['text_empty']      = '您没有购买过可下载的商品！';
?>