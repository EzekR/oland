<?php
/**
 * $Author: http://www.opencartchina.com 
**/
$_['paid_on_amazon_text'] = 'Amazon 支付';
$_['shipping_text'] = '配送';
$_['shipping_tax_text'] = '配送税率';
$_['gift_wrap_text'] = '包装';
$_['gift_wrap_tax_text'] = '包装税率';
$_['sub_total_text'] = '小计';
$_['tax_text'] = '税率';
$_['total_text'] = '总计'; 