<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading 
$_['heading_title']    = '加盟跟踪';

// Text
$_['text_account']     = '账户';
$_['text_description'] = '为了确保您能得到我们发送的付款，我们需要跟踪放置在URL跟踪代码链接给我们，您可以使用下面的工具来生成 %s 链接网站。';
$_['text_code']        = '<b>您的跟踪号：</b>';
$_['text_generator']   = '<b>跟踪链接生成</b><br />请输入你要生成链接的商品名：';
$_['text_link']        = '<b>跟踪链接：</b>';
?>