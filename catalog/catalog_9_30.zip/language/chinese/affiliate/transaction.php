<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading 
$_['heading_title']      = '我的交易';

// Column
$_['column_date_added']  = '交易日期';
$_['column_description'] = '说明';
$_['column_amount']      = '合计 (%s)';

// Text
$_['text_account']       = '账户';
$_['text_transaction']   = '我的交易';
$_['text_balance']       = '我的交易余额为：';
$_['text_empty']         = '您还没有任何交易记录！';
?>