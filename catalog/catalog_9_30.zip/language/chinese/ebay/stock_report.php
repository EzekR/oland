<?php
/**
 * $Author: http://www.opencartchina.com 
**/
$_['title']         = 'OpenBay Pro 列表';
$_['help']          = '详细说明';