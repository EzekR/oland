<?php
/**
 * $Author: http://www.opencartchina.com 
**/
$_['lang_shipping']     = '配送';
$_['lang_discount']     = '折扣';
$_['lang_tax']          = '税率';
$_['lang_subtotal']     = '小计';
$_['lang_total']        = '总计';
