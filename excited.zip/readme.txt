+========================================+
| Special with  CountDown MODULE v. 1.3  | 
|         www.oc-extensions.com          |
+========================================+


HOW TO INSTALL/USE
------------------

Full install/use documentation : http://www.oc-extensions.com/Special-Price-Countdown    (see Help Tab)
 