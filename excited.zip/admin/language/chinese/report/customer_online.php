<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Heading
$_['heading_title']     = '在线会员';

// Text 
$_['text_guest']        = '游客';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = '会员';
$_['column_url']        = '最近浏览页面';
$_['column_referer']    = '拓展自加盟会员';
$_['column_date_added'] = '最新日期';
$_['column_action']     = '操作';
?>