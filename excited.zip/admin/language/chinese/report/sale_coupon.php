<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Heading
$_['heading_title']    = '折扣统计报表';

// Column
$_['column_name']      = '折扣名称';
$_['column_code']      = '折扣代码';
$_['column_orders']    = '订单';
$_['column_total']     = '合计';
$_['column_action']    = '操作';

// Entry
$_['entry_date_start']  = '开始日期：';
$_['entry_date_end']    = '结束日期：';
?>