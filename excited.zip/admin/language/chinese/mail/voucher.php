<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Text
$_['text_subject']  = '您收到了来自于%s的礼品券';
$_['text_greeting'] = '恭喜，您收到了一份礼品券，价值%s';
$_['text_from']     = '您收到来自%s发送的礼品券';
$_['text_message']  = '礼品券信息';
$_['text_redeem']   = '要使用此礼品券，请牢记礼品券代码 <b>%s</b>，然后访问以下链接网站购买相关物品。您可以进入购物车页面上的【使用礼品券】功能，输入礼品券代码，然后单击【使用礼品券】按钮，然后结账。';
$_['text_footer']   = '如您有任何问题，请回复本邮件。';
?>