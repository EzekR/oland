<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Text
$_['text_approve_subject']      = '%s - 您的加盟会员账号已经被激活！';
$_['text_approve_welcome']      = '欢迎并感谢您注册到%s！';
$_['text_approve_login']        = '您的账户已创建并且您可以使用您的邮箱地址和密码从以下地址登入到我们的网站：';
$_['text_approve_services']     = '登入后，您将能够享受其他服务包括访问获取跟踪号，跟踪佣金情况和编辑您的账户信息！';
$_['text_approve_thanks']       = '谢谢！';
$_['text_transaction_subject']  = '%s - 加盟会员佣金';
$_['text_transaction_received'] = '您已拥有的佣金%s！';
$_['text_transaction_total']    = '您现在的佣金总额%s。';
?>