<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Text
$_['text_subject']  = '%s - 密码重置请求';
$_['text_greeting'] = '一个新的管理员密码%s.';
$_['text_change']   = '要重设密码点击以下链接：';
$_['text_ip']       = '要求重置密码的IP： %s';
?>