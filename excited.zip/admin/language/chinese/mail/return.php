<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Text
$_['text_subject']       = '%s - 退换  %s 更新';
$_['text_return_id']     = '退换 ID：';
$_['text_date_added']    = '退换的日期：';
$_['text_return_status'] = '您的退换已更新到以下状态：';
$_['text_comment']       = '您退换的意见：';
$_['text_footer']        = '如果您有任何问题请回复此电子邮件。';
?>