<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Heading
$_['heading_title']    = 'Klarna收费';

$_['text_total']       = '订单总计';
$_['text_success']     = '成功：Klarna收费更新完成！';
$_['text_sweden']      = 'Sweden';
$_['text_norway']      = 'Norway';
$_['text_finland']     = 'Finland';
$_['text_denmark']     = 'Denmark';
$_['text_germany']     = 'Germany';
$_['text_netherlands'] = 'The Netherlands';


// Entry
$_['entry_total']      = '订单总计：';
$_['entry_fee']        = '收费：';
$_['entry_tax_class']  = '税种：';
$_['entry_status']     = '状态：';
$_['entry_sort_order'] = '排序：';

// Error
$_['error_permission'] = '警告：您没有变更Klarna收费的权限！';
?>