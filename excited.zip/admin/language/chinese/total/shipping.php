<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Heading
$_['heading_title']    = '配送';

// Text
$_['text_total']       = '订单总计';
$_['text_success']     = '成功： 您已成功更改了配送方式！';

// Entry
$_['entry_estimator']  = '货运预估：';
$_['entry_status']     = '状态：';
$_['entry_sort_order'] = '排序：';

// Error
$_['error_permission'] = '警告：您没有变更配送设定的权限！';
?>