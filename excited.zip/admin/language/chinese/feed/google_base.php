<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Heading
$_['heading_title']    = 'Google Base';

// Text 
$_['text_feed']        = '插件扩展';
$_['text_success']     = '成功： 您已变更Google Base资料！';

// Entry
$_['entry_status']     = '状态：';
$_['entry_data_feed']  = '资料数据网址：';

// Error
$_['error_permission'] = '警告： 您没有权限修改Google Base相关资料！';
?>