<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Heading
$_['heading_title']   = '权限不足！'; 

// Text
$_['text_permission'] = '您没有权限访问此页面，请联系系统管理员。';
?>