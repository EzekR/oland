<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Text
$_['text_footer'] = '技术支持 无可奉告<br />Version %s';
?>