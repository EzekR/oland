<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// header
$_['heading_title']  = '欢迎来到商店后台管理系统';

// Text
$_['text_heading']   = '管理员登录系统，闲人免入！';
$_['text_login']     = '请输入您的登录信息。';
$_['text_forgotten'] = '忘记密码';

// Entry
$_['entry_username'] = '商店管理员：';
$_['entry_password'] = '安全密码：';

// Button
$_['button_login']   = '登录';

// Error
$_['error_login']    = '请输入有效的管理员帐号和密码！';
$_['error_token']    = '超时退出，请重新登录！';
?>
