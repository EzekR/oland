<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Heading
$_['heading_title']     = '订单总计';

// Text
$_['text_install']      = '安装';
$_['text_uninstall']    = '卸载';

// Column
$_['column_name']       = '订单总计';
$_['column_status']     = '状态';
$_['column_sort_order'] = '排序';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告： 您没有权限修改订单总计！';
?>