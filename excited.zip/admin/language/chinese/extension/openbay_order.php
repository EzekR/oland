<?php
/**
 * $Author: http://www.opencartchina.com 
**/

$_['lang_btn_status']           = '改变订单状态';
$_['lang_order_channel']        = '订单来源';
$_['lang_confirmed']            = '个已标记订单更新为';
$_['lang_no_orders']            = '未选择要更新的订单';
$_['lang_confirm_title']        = '订单状态批量更新预览';
$_['lang_confirm_change_text']  = '将订单状态改变为';
$_['lang_column_addtional']     = '附加信息';
$_['lang_column_comments']      = '备注';
$_['lang_column_notify']        = '通知';
$_['lang_carrier']              = 'Carrier';
$_['lang_tracking']             = '跟踪';
$_['lang_other']                = '其它';
$_['lang_refund_reason']        = '退款原因';
$_['lang_refund_message']       = '退款信息';
$_['lang_update']               = '确认更新';
$_['lang_cancel']               = '取消';
$_['lang_e_ajax_1']             = 'A play order is missing a refund message!';
$_['lang_e_ajax_2']             = 'A play order is missing tracking info!';
$_['lang_e_ajax_3']             = 'An Amazon order is missing an "Other Carrier" entry!';
$_['lang_title_order_update']   = '批量订单更新';
