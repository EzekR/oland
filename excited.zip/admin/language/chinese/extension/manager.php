<?php
/**
 * $Author: http://www.opencartchina.com 
**/

// Heading 
$_['heading_title']    = '扩展功能模组管理';

// Text
$_['text_success']     = '已成功修改扩展功能模组管理';

// Error
$_['error_permission'] = '您没有权限修改扩展功能模组管理设置';
$_['error_upload']     = '尚未选择要上传的文档';
$_['error_filetype']   = '不支持的文档类型';
?>